package json;

public class ExtMessage implements Cloneable{

    @Override
    public ExtMessage clone() throws CloneNotSupportedException {
        return (ExtMessage) super.clone();
    }
}
