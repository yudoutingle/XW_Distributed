package json.config;

public class Config extends NodeConfig{
    public MainConfig mainConfig;
    public ChannelConfig channelConfig;
    public MessageConfig messageConfig;
}
