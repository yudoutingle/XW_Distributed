package json.config;

public class ChannelDetialConfig {
    public float lag;
    public int maxCount;
    public float buildTime;
    public int maxMessageCount;
}
