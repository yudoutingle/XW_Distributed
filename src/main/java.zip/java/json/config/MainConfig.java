package json.config;

public class MainConfig {
    public int nodeCount;
    public float timeOut;
    public String masterIp;
    public int masterPort;
}
