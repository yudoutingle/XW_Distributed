package json.config;

public class NodeConfig {
    public int index;
    public int maxChannelConn;
}
