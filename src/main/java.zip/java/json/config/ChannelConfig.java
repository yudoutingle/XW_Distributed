package json.config;

public class ChannelConfig {
    public ChannelDetialConfig highSpeed;
    public ChannelDetialConfig normalSpeed;
}
