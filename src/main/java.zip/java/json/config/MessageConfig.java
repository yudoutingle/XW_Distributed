package json.config;

public class MessageConfig {
    public int maxPendingMsgSize;
    public int maxCallMsgSize;
    public int maxInnerMsgSize;
}
